package com.example.po;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_main);
        ArrayList <pokemon> pokemonpall = new ArrayList<>();
        pokemon n = new pokemon("Bulbasaur",R.drawable.venusaur,200,400,600);
        pokemon y = new pokemon(" Ivysaur",R.drawable.venusaur,100,600,700);
        pokemon t = new pokemon("Venusaur",R.drawable.venusaur,300,500,800);
        pokemon r = new pokemon("Venusaur",R.drawable.venusaur,300,500,800);
        pokemon o = new pokemon("Venusaur",R.drawable.venusaur,300,500,800);

        pokemonpall.add(n);//0
        pokemonpall.add(y);//1
        pokemonpall.add(t);//2
        pokemonpall.add(t);//3
        pokemonpall.add(t);//4


        RecyclerView rv = findViewById(R.id.rec);
        rv.setHasFixedSize(true);
        RecyclerView.LayoutManager lm = new LinearLayoutManager(this);
        rv.addItemDecoration(new DividerItemDecoration(this,DividerItemDecoration.HORIZONTAL));
        rv.setLayoutManager(lm);
        pokemonAdapter po =new pokemonAdapter(pokemonpall,this);
        rv.setAdapter(po);

    }
}