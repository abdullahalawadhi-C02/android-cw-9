package com.example.po;

public @interface Overrid {
}
