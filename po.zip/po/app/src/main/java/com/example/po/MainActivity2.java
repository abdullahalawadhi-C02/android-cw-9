package com.example.po;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.Serializable;

public class MainActivity2 extends AppCompatActivity   {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Bundle b = getIntent().getExtras();
        pokemon p = (pokemon) b.getSerializable("pokemon");


        ImageView img = findViewById(R.id.imageView2);
        TextView t = findViewById(R.id.textView4);
        TextView ti = findViewById(R.id.textView5);
        TextView tie = findViewById(R.id.textView6);

        img.setImageResource(p.getImage());
        t.setText(p.getName());
        ti.setText("Attack:"+p.getAttack());
        tie.setText("Defence:"+p.getDefence());
    }
}